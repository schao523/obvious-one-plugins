"""Python package marker for vendored RAG modules."""
