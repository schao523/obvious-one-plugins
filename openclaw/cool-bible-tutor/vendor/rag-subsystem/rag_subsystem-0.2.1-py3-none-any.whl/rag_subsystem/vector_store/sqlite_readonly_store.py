"""Immutable SQLite vector store for compact, distributable runtime indexes."""
from __future__ import annotations

from array import array
import json
from pathlib import Path
import sqlite3
import sys
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from .base import VectorStore
from .doc_filter import chunk_matches_doc_filter, normalize_doc_filter
from .json_file_store import _cosine, _lexical_score
from ..schemas import Chunk


RUNTIME_INDEX_SCHEMA = """
CREATE TABLE index_metadata (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE chunks (
    chunk_id TEXT PRIMARY KEY,
    source_order INTEGER NOT NULL UNIQUE,
    doc_id TEXT NOT NULL,
    text TEXT NOT NULL,
    section_path TEXT,
    chunk_order INTEGER NOT NULL,
    language TEXT NOT NULL,
    embedding_model TEXT NOT NULL,
    namespace TEXT NOT NULL,
    app_id TEXT,
    embedding BLOB NOT NULL,
    metadata_json TEXT NOT NULL,
    content_hash TEXT NOT NULL
);
CREATE INDEX chunks_namespace_app_id_idx ON chunks(namespace, app_id);
CREATE INDEX chunks_doc_id_idx ON chunks(doc_id);
"""


def encode_float32(values: Sequence[float]) -> bytes:
    """Encode floats as portable little-endian IEEE-754 float32 bytes."""
    encoded = array("f", values)
    if encoded.itemsize != 4:
        raise RuntimeError("This Python runtime does not provide 32-bit array('f') values")
    if sys.byteorder != "little":
        encoded.byteswap()
    return encoded.tobytes()


def decode_float32(blob: bytes, expected_dimensions: int) -> List[float]:
    """Decode a little-endian float32 vector and enforce its dimensions."""
    values = array("f")
    values.frombytes(blob)
    if values.itemsize != 4:
        raise RuntimeError("This Python runtime does not provide 32-bit array('f') values")
    if sys.byteorder != "little":
        values.byteswap()
    if len(values) != expected_dimensions:
        raise ValueError(
            f"Embedding dimension mismatch: expected={expected_dimensions} chunk={len(values)}"
        )
    return values.tolist()


class SqliteReadonlyVectorStore(VectorStore):
    """Read a release index without ever creating journals or modifying the asset."""

    def __init__(self, path: str):
        self.path = Path(path).expanduser().resolve()
        if not self.path.is_file():
            raise FileNotFoundError(f"SQLite runtime index not found: {self.path}")
        uri = self.path.as_uri() + "?mode=ro&immutable=1"
        self.connection = sqlite3.connect(uri, uri=True)
        self.connection.row_factory = sqlite3.Row
        self.dimensions = self._validate_schema()

    def _validate_schema(self) -> int:
        tables = {
            row[0]
            for row in self.connection.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }
        required = {"index_metadata", "chunks"}
        if not required.issubset(tables):
            missing = ", ".join(sorted(required - tables))
            raise ValueError(f"Invalid SQLite runtime index schema; missing table(s): {missing}")
        metadata = dict(self.connection.execute("SELECT key, value FROM index_metadata"))
        try:
            dimensions = int(metadata["dimensions"])
            item_count = int(metadata["item_count"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError("Invalid SQLite runtime index metadata") from exc
        if dimensions <= 0 or item_count < 0:
            raise ValueError("Invalid SQLite runtime index dimensions or item count")
        actual_count = self.connection.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        if actual_count != item_count:
            raise ValueError(
                f"SQLite runtime index item count mismatch: metadata={item_count} actual={actual_count}"
            )
        return dimensions

    def _candidate_chunks(
        self,
        namespace: str,
        app_id: str | None,
        doc_filter: Dict[str, Any] | None,
    ) -> Iterable[Chunk]:
        clauses = ["namespace = ?"]
        parameters: List[Any] = [namespace]
        if app_id is not None:
            clauses.append("app_id = ?")
            parameters.append(app_id)
        query = (
            "SELECT * FROM chunks WHERE "
            + " AND ".join(clauses)
            + " ORDER BY source_order"
        )
        normalized_doc_filter = normalize_doc_filter(doc_filter)
        for row in self.connection.execute(query, parameters):
            try:
                metadata = json.loads(row["metadata_json"])
            except (TypeError, json.JSONDecodeError) as exc:
                raise ValueError(f"Invalid metadata JSON for chunk {row['chunk_id']}") from exc
            chunk = Chunk(
                doc_id=row["doc_id"],
                chunk_id=row["chunk_id"],
                text=row["text"],
                section_path=row["section_path"],
                order=row["chunk_order"],
                language=row["language"],
                embedding_model=row["embedding_model"],
                namespace=row["namespace"],
                embedding=decode_float32(row["embedding"], self.dimensions),
                metadata=metadata,
                hash=row["content_hash"],
            )
            if chunk_matches_doc_filter(chunk, normalized_doc_filter):
                yield chunk

    @staticmethod
    def _read_only() -> None:
        raise RuntimeError("SQLite runtime index is read-only")

    def upsert(self, chunks: Sequence[Chunk]) -> None:
        self._read_only()

    def delete_by_doc_id(self, doc_id: str, app_id: str | None = None) -> None:
        self._read_only()

    def semantic_search(
        self,
        query_embedding: List[float],
        namespace: str,
        top_k: int,
        app_id: str | None = None,
        doc_filter: Dict[str, Any] | None = None,
    ) -> List[Tuple[Chunk, float]]:
        if len(query_embedding) != self.dimensions:
            raise ValueError(
                f"Embedding dimension mismatch: query={len(query_embedding)} expected={self.dimensions}"
            )
        scored = [
            (chunk, _cosine(query_embedding, chunk.embedding))
            for chunk in self._candidate_chunks(namespace, app_id, doc_filter)
        ]
        scored.sort(key=lambda item: item[1], reverse=True)
        return scored[:top_k]

    def metadata_search(
        self,
        filters: Dict[str, Any],
        namespace: str,
        top_k: int,
        app_id: str | None = None,
        doc_filter: Dict[str, Any] | None = None,
    ) -> List[Tuple[Chunk, float]]:
        results = []
        for chunk in self._candidate_chunks(namespace, app_id, doc_filter):
            if all(chunk.metadata.get(key) == value for key, value in filters.items()):
                results.append((chunk, 1.0))
        return results[:top_k]

    def lexical_search(
        self,
        query_text: str,
        namespace: str,
        top_k: int,
        app_id: str | None = None,
        doc_filter: Dict[str, Any] | None = None,
    ) -> List[Tuple[Chunk, float]]:
        scored = []
        for chunk in self._candidate_chunks(namespace, app_id, doc_filter):
            score = _lexical_score(query_text, chunk.text)
            if score > 0:
                scored.append((chunk, score))
        scored.sort(key=lambda item: item[1], reverse=True)
        return scored[:top_k]
